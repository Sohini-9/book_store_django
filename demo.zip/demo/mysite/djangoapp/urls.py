from django.contrib import admin
from django.urls import path
from djangoapp import views    #we are importing views because it is present in djangoapp and urls.py is presnt in mysite

app_name = 'djangoapp' #this is like mentioning this url name is for djangoapp like if any other person in the project creates the url with the same name

urlpatterns = [
    path('',views.index,name='index'),
    #path('products/',views.products,name='products'),
    #book/2
    path('book/<int:book_id>/',views.detail,name='detail'),
    path('add/',views.add_book),
    path('update/<int:id>/',views.update,name='update'),
    path('delete/<int:id>/',views.delete,name='delete')
]
