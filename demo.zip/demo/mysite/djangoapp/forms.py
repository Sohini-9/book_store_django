from django import forms
from .models import Book

class BookForm(forms.ModelForm):
    class Meta:                                               #a meta-class is a class which holds the information of the class itself
        model = Book
        fields = ['name','desc','book_image','price']

